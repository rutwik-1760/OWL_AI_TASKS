require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');
const habitsRoute = require('./routes/habits');

const PORT = process.env.PORT || 5000;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/smart_habit_builder';

connectDB(MONGODB_URI);

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/habits', habitsRoute);

app.get('/', (req, res) => res.send('Smart Habit Builder API'));

app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));
