const express = require('express');
const router = express.Router();
const Habit = require('../models/Habit');

// helper: getUTCDateStart - normalize to UTC midnight
function getUTCDateStart(d = new Date()){
  const date = new Date(d);
  date.setUTCHours(0,0,0,0);
  return date;
}

// GET all habits
router.get('/', async (req, res) => {
  const habits = await Habit.find().sort({ createdAt: -1 });
  res.json(habits);
});

// CREATE
router.post('/', async (req, res) => {
  const body = req.body;
  const h = new Habit(body);
  await h.save();
  res.status(201).json(h);
});

// READ single
router.get('/:id', async (req, res) => {
  const h = await Habit.findById(req.params.id);
  if (!h) return res.status(404).json({ message: 'Habit not found' });
  res.json(h);
});

// UPDATE
router.put('/:id', async (req, res) => {
  const h = await Habit.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(h);
});

// DELETE
router.delete('/:id', async (req, res) => {
  await Habit.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
});

// RECORD completion for a day (awards streaks)
router.post('/:id/complete', async (req, res) => {
  const id = req.params.id;
  const { date } = req.body; // optional ISO date string
  const day = getUTCDateStart(date ? new Date(date) : new Date());
  const habit = await Habit.findById(id);
  if(!habit) return res.status(404).json({ message: 'Not found' });

  // avoid duplicate completion for same date
  const exists = habit.completions.some(c => c.date.getTime() === day.getTime());
  if (exists) return res.json(habit);

  habit.completions.push({ date: day, done: true });

  // recompute streak: look back day-by-day
  let streak = 0;
  const completionsSet = new Set(habit.completions.map(c => c.date.getTime()));
  let cursor = new Date(day);
  while(true){
    const time = cursor.getTime();
    if (completionsSet.has(time)){
      streak++;
      cursor.setUTCDate(cursor.getUTCDate() - 1);
      cursor.setUTCHours(0,0,0,0);
    } else break;
  }
  habit.streak = streak;
  if (streak > habit.bestStreak) habit.bestStreak = streak;
  await habit.save();
  res.json(habit);
});

// SUGGEST endpoint: basic heuristics to recommend habits
router.get('/suggestions/auto', async (req, res) => {
  // Very simple heuristic-based suggestions using existing habits and activity:
  // - If user frequently completes tasks late (local time hour >= 21), suggest "Evening routine"
  // - If user frequently completes "read" or "book" tasks, suggest "Daily reading 20 mins"
  // - If user has few habits, suggest core daily micro-habits
  const habits = await Habit.find();
  const suggestions = [];

  // default core suggestions
  const core = [
    { title: 'Daily 5-minute reflection', reason: 'Build habit of nightly review' },
    { title: 'Morning stretch (5 min)', reason: 'Quick physical activity to start the day' },
    { title: 'Read 10 pages', reason: 'Micro reading habit' }
  ];
  if (habits.length < 3) suggestions.push(...core);

  // check for keywords in existing habits
  const titles = habits.map(h => h.title.toLowerCase());
  if (titles.some(t => t.includes('run') || t.includes('exercise') || t.includes('gym'))) {
    suggestions.push({ title: 'Short warm-up (10 min)', reason: 'Increase physical consistency' });
  }
  if (titles.some(t => t.includes('read') || t.includes('book') || t.includes('study'))) {
    suggestions.push({ title: 'Daily reading (20 min)', reason: 'Scale up reading habit' });
  }

  // analyze completions time-of-day heuristics (best-effort)
  const allCompletions = habits.flatMap(h => h.completions || []);
  if (allCompletions.length > 5) {
    // extract hours of completion (UTC -> local not handled here; assume UTC)
    const lateCount = allCompletions.filter(c => {
      const hr = new Date(c.date).getUTCHours();
      return hr >= 20 || hr <= 4; // late-night
    }).length;
    if (lateCount / allCompletions.length > 0.3) {
      suggestions.push({ title: 'Evening wind-down (10 min)', reason: 'You often work late — try a short evening routine' });
    }
  }

  // dedupe suggestions
  const seen = new Set();
  const final = [];
  for (const s of suggestions) {
    const key = s.title.toLowerCase();
    if (!seen.has(key)) { seen.add(key); final.push(s); }
  }

  // limit to 5
  res.json(final.slice(0,5));
});

module.exports = router;
