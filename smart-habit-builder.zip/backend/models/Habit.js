const mongoose = require('mongoose');

const CompletionSchema = new mongoose.Schema({
  date: { type: Date, required: true }, // UTC midnight for the day
  done: { type: Boolean, default: true }
}, { _id: false });

const HabitSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: String,
  frequency: { type: String, enum: ['daily','weekdays','custom'], default: 'daily' },
  daysOfWeek: [Number], // 0-6 (Sun-Sat) used when frequency == 'custom' or 'weekdays'
  streak: { type: Number, default: 0 },
  bestStreak: { type: Number, default: 0 },
  completions: [CompletionSchema], // array of completion days
  createdAt: { type: Date, default: Date.now },
  tags: [String]
});

HabitSchema.methods.recordCompletion = function(date){
  // date should be Date at UTC midnight
  this.completions.push({ date, done: true });
  // update streak and bestStreak later in route
  return this;
};

module.exports = mongoose.model('Habit', HabitSchema);
