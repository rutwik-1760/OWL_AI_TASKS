const API = 'http://localhost:5000/api/habits';
const habitsEl = document.getElementById('habits');
const detailArea = document.getElementById('detailArea');
const chartEl = document.getElementById('progressChart');
let habits = [];
let selected = null;

async function fetchHabits(){
  const res = await fetch(API);
  habits = await res.json();
  renderList();
}

function renderList(){
  habitsEl.innerHTML = '';
  for(const h of habits){
    const li = document.createElement('li');
    li.className = 'habit';
    li.innerHTML = `<div>
      <strong>${h.title}</strong>
      <div class="meta">Streak: ${h.streak || 0} • Best: ${h.bestStreak || 0}</div>
    </div>
    <div>
      <button onclick="viewHabit('${h._id}')">View</button>
      <button onclick="complete('${h._id}')">Complete</button>
      <button onclick="remove('${h._id}')">Delete</button>
    </div>`;
    habitsEl.appendChild(li);
  }
}

async function addHabit(){
  const title = document.getElementById('title').value.trim();
  const tags = document.getElementById('tags').value.split(',').map(s=>s.trim()).filter(Boolean);
  const frequency = document.getElementById('frequency').value;
  if(!title) return alert('Title required');
  const res = await fetch(API, {
    method:'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ title, tags, frequency })
  });
  const h = await res.json();
  habits.unshift(h);
  renderList();
  document.getElementById('title').value = '';
  document.getElementById('tags').value = '';
}

async function complete(id){
  // record completion for today
  const res = await fetch(`${API}/${id}/complete`, {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({}) // server uses today if none provided
  });
  const updated = await res.json();
  const idx = habits.findIndex(h=>h._id===id);
  if(idx>=0) habits[idx] = updated;
  renderList();
  if(selected && selected._id===id) viewHabit(id);
}

async function remove(id){
  await fetch(`${API}/${id}`, { method:'DELETE' });
  habits = habits.filter(h=>h._id!==id);
  renderList();
  detailArea.innerHTML = 'Select a habit to see progress';
  chartEl.style.display='none';
}

function viewHabit(id){
  selected = habits.find(h => h._id === id);
  if(!selected) return;
  detailArea.innerHTML = `<h4>${selected.title}</h4>
    <p>${selected.description || ''}</p>
    <p>Streak: ${selected.streak || 0} • Best: ${selected.bestStreak || 0}</p>
    <p>Completions: ${selected.completions ? selected.completions.length : 0}</p>
    <p>Tags: ${(selected.tags || []).join(', ')}</p>
  `;
  renderChart(selected);
}

function renderChart(habit){
  chartEl.style.display='block';
  const ctx = chartEl.getContext('2d');
  // prepare last 14 days data
  const last14 = [];
  const labels = [];
  const now = new Date();
  for(let i=13;i>=0;i--){
    const d = new Date(now);
    d.setDate(now.getDate() - i);
    d.setHours(0,0,0,0);
    labels.push(d.toLocaleDateString());
    const found = (habit.completions || []).some(c => new Date(c.date).getTime() === d.getTime());
    last14.push(found ? 1 : 0);
  }
  if(window._chart) window._chart.destroy();
  window._chart = new Chart(ctx, {
    type:'bar',
    data: { labels, datasets: [{ label: 'Done (last 14 days)', data: last14 }] },
    options: { scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } } }
  });
}

// suggestions
document.getElementById('suggestBtn').addEventListener('click', async ()=>{
  const res = await fetch(`${API}/suggestions/auto`);
  const suggestions = await res.json();
  const panel = document.getElementById('suggestionsPanel');
  const list = document.getElementById('suggestions');
  list.innerHTML = '';
  for(const s of suggestions){
    const li = document.createElement('li');
    li.innerHTML = `<strong>${s.title}</strong><div>${s.reason || ''}</div><button onclick='applySuggestion(${JSON.stringify(s).replace(/'/g,"\\'")})'>Add</button>`;
    list.appendChild(li);
  }
  panel.classList.remove('hidden');
});
document.getElementById('closeSug').addEventListener('click', ()=> document.getElementById('suggestionsPanel').classList.add('hidden'));

async function applySuggestion(s){
  const res = await fetch(API, {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ title: s.title, description: s.reason, frequency: 'daily' })
  });
  const h = await res.json();
  habits.unshift(h);
  renderList();
  document.getElementById('suggestionsPanel').classList.add('hidden');
}

// wire add button
document.getElementById('add').addEventListener('click', addHabit);

// initial load
fetchHabits();
