# Smart Habit Builder

Smart Habit Builder is a simple, opinionated habit-tracking web app that helps users form daily habits and suggests new habits based on usage patterns.

## Features
- Create, update, delete habits
- Record daily completions and track streaks
- Auto-suggestion endpoint that recommends new habits based on activity
- Visualize recent completion history
- Simple heuristics-based recommendations (extendable)

## Tech Stack
- Backend: Node.js, Express, MongoDB (Mongoose)
- Frontend: HTML, CSS, JavaScript, Chart.js

## Quickstart (local)

### Prereqs
- Node.js (16+), npm
- MongoDB local or Atlas

### Backend
```bash
cd backend
cp .env.example .env
# edit .env to point MONGODB_URI
npm install
npm run dev   # or npm start
```

### Frontend
Open `frontend/index.html` in your browser (or run a static server: `npx http-server frontend`).

## API Endpoints
- `GET /api/habits` – list habits  
- `POST /api/habits` – create habit  
- `GET /api/habits/:id` – get habit  
- `PUT /api/habits/:id` – update habit  
- `DELETE /api/habits/:id` – remove habit  
- `POST /api/habits/:id/complete` – record completion for today  
- `GET /api/habits/suggestions/auto` – get suggestions

## Contributing & Improvements
- Improve suggestion logic with ML or user preferences
- Add user authentication (per-user habits)
- Persist settings and use IndexedDB for offline support

## License
MIT
